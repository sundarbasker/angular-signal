import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { App } from './app/app';

import { ApplicationConfig } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { Todo } from './app/todo/todo';

export const main: ApplicationConfig = {
  providers: [provideHttpClient(), Todo]
};

bootstrapApplication(App, appConfig)
  .catch((err) => console.error(err));
