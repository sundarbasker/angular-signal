import { Component } from '@angular/core';
import { UserService } from '../user-service';
import { JsonPipe } from '@angular/common';
import { Postservice } from '../postservice';
import { Post } from '../interface/post';

@Component({
  selector: 'app-list-service',
  imports: [],
  templateUrl: './list-service.html',
  styleUrl: './list-service.scss',
})
export class ListService {

  userService: any;

  posts: Array<any> = [];
post: any;

  constructor(private userservice: UserService, private postService: Postservice) { 
    // this.userService = new UserService();
    // console.log(this.userService);
this.posts = postService.getPost();

  }

  addPost(){
    let postData: Post = {
      id: 7,
      title: 'Post title 7',
      post: 'Dummy post 7'
    }


    this.postService.addPostService(postData);
  }


  

}
