import { Component, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  imports: [],
  templateUrl: './child.html',
  styleUrl: './child.scss',
})
export class Child {

  @Input() name: string = '';
  @Input() bio: string = '';
  @Input() imageUrl: string = 'https://angular.dev/assets/images/press-kit/angular_wordmark_gradient.png';

  @Input() postListTitle: string = '';

  childMessage: string = "Hello from Child Component using @Viewchild method";

  postCount: number = 0;

  parentMessage: string = 'Message from child using click event';

  @Output() MessageEvent = new EventEmitter();

  sendMessage(){
    console.log('Button Clicked');
    this.MessageEvent.emit(this.parentMessage);
  }


}
