import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { Child } from "./child/child";

@Component({
  selector: 'app-parent',
  imports: [Child],
  templateUrl: './parent.html',
  styleUrl: './parent.scss',
})
export class Parent implements AfterViewInit {

  @ViewChild(Child) childMessage: any;
  message: any = '';

  messageFromChild: string = '';

  constructor(){
    console.log(this.childMessage);
  }

  ngAfterViewInit(): void {
    console.log(this.childMessage);
    this.message = this.childMessage.childMessage;
  }

  receiveMessage(message: string){
console.log(message);
this.messageFromChild = message;
  }

  userData = {
    name: 'Jane Doe',
    bio: 'Frontend Developer & UI/UX enthusiast',
    image: 'https://angular.dev/assets/images/press-kit/angular_wordmark_gradient.png'
  };

  appPostTitle: string = 'Post 1';

}
  