import { CurrencyPipe, DatePipe, DecimalPipe, JsonPipe, LowerCasePipe, PercentPipe, SlicePipe, TitleCasePipe, UpperCasePipe } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-pipe',
  imports: [UpperCasePipe, LowerCasePipe, TitleCasePipe,
     DecimalPipe, PercentPipe, CurrencyPipe, DatePipe, JsonPipe, SlicePipe],
  templateUrl: './pipe.html',
  styleUrl: './pipe.scss',
})
export class Pipe {

  title: string = 'angular app';

  today = new Date();

  user: object = {
    name: 'John Doe',
    age: 30,
    email: 'john@gmail.com'
  }

  convertJson(){
   // this.user = JSON.stringify(this.user);
  }
}
