import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Counter {
  serviceSignalCounter = signal(0);

  incrementCounter(){
    this.serviceSignalCounter.update(
      (currentValue) => {
        return currentValue + 1;
      }
    )
  }
  
}
