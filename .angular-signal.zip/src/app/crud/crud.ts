import { Component, inject, OnInit } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { Movie, Movies, User } from '../movies';
import { UserService } from '../user-service';

@Component({
  selector: 'app-crud',
  imports: [],
  templateUrl: './crud.html',
  styleUrl: './crud.scss',
})
export class Crud {

  private userService = inject(Movies);

  moviee = toSignal(this.userService.getUsers(),{ initialValue: []});

  movies = toSignal(this.userService.getMovies(),
{ initialValue: [] as Movie[] });

  onAddTest(){   
    const movie = {
      title: 'Test Movie',
      year: 2026,
      director: 'John Doe'
    };
    this.userService.addMovie(movie)
    .subscribe((created: any) => {
      console.log('Created', created)
    })
  }

 users = toSignal(
    this.userService.getUsers(),
   // { initialValue: []  }
   { initialValue: [] as User[]  }
    
  );

  // ngOnInit(): void {
  //   this.UserService.getUsers()
  //   .subscribe(data =>{
  //     console.log('got users', data);
  //   })
  // }

}
