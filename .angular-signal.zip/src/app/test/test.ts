import { Component, inject,  signal, computed } from '@angular/core';
import { FormBuilder, FormArray, ReactiveFormsModule, FormsModule, Validators } from '@angular/forms';
import { retry } from 'rxjs';

@Component({
  selector: 'app-test',
  imports: [FormsModule, ReactiveFormsModule],
  templateUrl: './test.html',
  styleUrl: './test.scss',
  standalone: true
})
export class Test {
title = 'Skills 17';

changeTitle(){
  this.title = this.title.toUpperCase();
}


  count: number = 0;

  increment(){
    this.count++;
     if(this.count>=0){
let a = document.getElementById('num')as HTMLElement;
    a.style.color = 'green';
     }
    
  }

  decrement(){
    if(this.count>0){
      this.count--;     
    }
    if(this.count<=0){
       this.count--;    
       let a = document.getElementById('num')as HTMLElement;
    a.style.color = 'red';
    }
  }

  reset(){
    this.count = 0;
    let a = document.getElementById('num')as HTMLElement;
    a.style.color = 'black'; 
  }

  isVisible = false;

  toggleVisibility(){
    this.isVisible = !this.isVisible;
  }


  hobbies: string[] = ['Reading', 'Cycling', 'Coding'];
  newHobby: string = '';

categories = ['Electronics', 'Clothing', 'Home'];
  allProducts = [
    { id: 1, name: 'Phone', category: 'Electronics' },
    { id: 2, name: 'Shirt', category: 'Clothing' },
    { id: 3, name: 'Lamp', category: 'Home' }
  ];
  filteredTableData: any[] = [];

  // Method triggered by dropdown change
  onCategoryChange(selectedValue: string) {
    this.filteredTableData = this.allProducts.filter(item => item.category === selectedValue);
  }
  
  addHobby(){
    if(this.newHobby.trim()){
      this.hobbies.push(this.newHobby);
      this.newHobby = '';
    }
  }

  removeHobby(index : number){
    this.hobbies.splice(index, 1);
  }


  trackById(index: number, hobby: any): number {
  return hobby.id; // Returns the unique identifier
}

 private fb = inject(FormBuilder);

 orderForm = this.fb.group({
  items: this.fb.array([])
 });

 get items(){
  return this.orderForm.controls['items']as FormArray;
 }

 addRow(){
  const itemGroup = this.fb.group({
    product: ['', Validators.required],
    quantity: [1, Validators.required]
  });
  this.items.push(itemGroup);
 }
 
 removeRow(index:number){
  this.items.removeAt(index);
 }

 /* 1. Initialize a FormGroup containing a FormArray

 profileForm = this.fb.group({
  skills: this.fb.array([
    this.fb.control('name') // Initial control
  ])
 });

 // 2. Use a getter for easy access in the template

 get skills(){
  return this.profileForm.get('skills')as FormArray;
 }

 // 3. Methods to add and remove controls

 addSkill(){
  this.skills.push(this.fb.control(''));
 }

 removeSkill(index: number){
this.skills.removeAt(index);
 }*/

// Raw data
  private allData = [
    { id: 1, name: 'Phone', category: 'Electronics' },
    { id: 2, name: 'Chair', category: 'Furniture' },
    { id: 3, name: 'Laptop', category: 'Electronics' },
    { id: 4, name: 'Sofa', category: 'Furniture' }
  ];

  // Signal to hold the current active filter
  filterCriteria = signal<string>('');

  // Computed signal automatically updates when filterCriteria changes
  filteredData = computed(() => {
    const criteria = this.filterCriteria();
    return criteria
      ? this.allData.filter(item => item.category === criteria)
      : this.allData;
  });

  applyFilter(value: string) {
    this.filterCriteria.set(value);
  }
}
