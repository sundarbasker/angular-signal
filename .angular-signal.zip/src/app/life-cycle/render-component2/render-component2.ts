import { Component, Input, OnChanges, SimpleChanges, OnInit, DoCheck, AfterViewChecked, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-render-component2',
  imports: [],
  templateUrl: './render-component2.html',
  styleUrl: './render-component2.scss',
})
export class RenderComponent2 implements OnChanges, OnInit, DoCheck, AfterViewChecked, OnDestroy {

  @Input() pUserName: string = '';
  counter: number = 0;

  ngOnInit(): void {
    console.log('NgOninit Hook Triggered');
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log('OnChanges Triggered');
  }

  ngDoCheck(): void {
    console.log('ngDoCheck Triggered');
  }

  ngAfterViewChecked(): void {
    console.log('ngAfterViewChecked');
  }
  ngOnDestroy(): void {
    console.log('ngOnDestroy Triggered');
  }

  increment(){
this.counter ++;
  }
}
