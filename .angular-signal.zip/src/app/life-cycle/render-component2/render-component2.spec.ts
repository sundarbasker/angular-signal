import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RenderComponent2 } from './render-component2';

describe('RenderComponent2', () => {
  let component: RenderComponent2;
  let fixture: ComponentFixture<RenderComponent2>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RenderComponent2]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RenderComponent2);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
