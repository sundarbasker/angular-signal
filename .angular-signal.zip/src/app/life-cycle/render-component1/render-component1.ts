
import { Component, ViewContainerRef } from '@angular/core';
import { RenderComponent2 } from '../render-component2/render-component2';


@Component({
  selector: 'app-render-component1',
  imports: [RenderComponent2],
  templateUrl: './render-component1.html',
  styleUrl: './render-component1.scss',
})
export class RenderComponent1 {

  userName: string = 'John Doe';

  constructor(private viewContainer: ViewContainerRef){
    console.log('Constructed Method Triggered');
    console.log(this.userName);
  }

  loadComponent(){
    // return RenderComponent2;

    this.viewContainer.createComponent(RenderComponent2);
  }

  removeComponent(){
    this.viewContainer.remove();
  }

  changeUser(){
    this.userName = 'John Smith';
  }
}
