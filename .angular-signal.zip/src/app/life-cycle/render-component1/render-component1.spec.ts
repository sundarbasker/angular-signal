import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RenderComponent1 } from './render-component1';

describe('RenderComponent1', () => {
  let component: RenderComponent1;
  let fixture: ComponentFixture<RenderComponent1>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RenderComponent1]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RenderComponent1);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
