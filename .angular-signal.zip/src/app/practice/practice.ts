import { NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-practice',
  imports: [FormsModule, NgIf],
  templateUrl: './practice.html',
  styleUrl: './practice.scss',
})
export class Practice {

  userName: string = 'John Doe';

  updateUserName(username: HTMLInputElement){
    this.userName = username.value;
    console.log(this.userName);
  }

  isLoggedIn: boolean = true;

  loginCount: number = 0;

  clontLogin(){
    this.loginCount ++;
    console.log(this.loginCount);
  }

  usersObj: Array<any> = [
    { id: 1, name: 'John', email: 'john@gmail.com' },
    { id: 2, name: 'Smith', email: 'Smith@gmail.com' },
    { id: 3, name: 'Sam', email: 'Sam@gmail.com' },
    { id: 1, name: 'Raj', email: 'Raj@gmail.com' },       
  ]

  addNewUser(){
    let user = {id: 5, name: 'Kiran', email: 'Kiran@gmail.com' };
    this.usersObj.push(user);    
  }

  onDelete(user:object){
    let index = this.usersObj.indexOf(user);
    this.usersObj.splice(index, 1);
  }

  onDelete1(index: number){
this.usersObj.splice(index, 1);
  }

  userRole: string = 'Admin';
}
