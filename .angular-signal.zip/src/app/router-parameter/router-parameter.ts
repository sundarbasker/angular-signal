import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-router-parameter',
  imports: [],
  templateUrl: './router-parameter.html',
  styleUrl: './router-parameter.scss',
})
export class RouterParameter {

  constructor( private route: ActivatedRoute){}

  ngOnInit():void {

    this.route.paramMap.subscribe(value => {
      //console.log(value);

      let id = value.get('id');
      const title = value.get('title');
      console.log(id);
      console.log(title);
    })
  }



  
}
