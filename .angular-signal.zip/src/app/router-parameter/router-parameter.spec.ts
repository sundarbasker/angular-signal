import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RouterParameter } from './router-parameter';

describe('RouterParameter', () => {
  let component: RouterParameter;
  let fixture: ComponentFixture<RouterParameter>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterParameter]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RouterParameter);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
