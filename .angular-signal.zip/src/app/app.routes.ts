import { Routes } from '@angular/router';
import { List } from './list/list';
import { App } from './app';
import { Form } from './form/form';
import { Login } from './login/login';
import { Test } from './test/test';
import { Parent } from './parent/parent';
import { Todo } from './todo/todo';
import { Practice } from './practice/practice';
import { RenderComponent1 } from './life-cycle/render-component1/render-component1';
import { RenderComponent2 } from './life-cycle/render-component2/render-component2';
import { Pipe } from './pipe/pipe';
import { ListService } from './list-service/list-service';
import { RouterParameter } from './router-parameter/router-parameter';
import { Post } from './post/post';
import { Signals } from './signals/signals';
import { Crud } from './crud/crud';
import { Add } from './employee/add/add';
import { Emplist } from './employee/emplist/emplist';

export const routes: Routes = [
    {path: '', component: Login},
    {path: 'list', component: List},
    {path: 'form', component: Form},
    {path: 'test', component: Test},
    {path: 'parent', component: Parent},
    {path: 'todo', component: Todo},
    {path: 'practice', component: Practice},
    {path: 'render1', component: RenderComponent1},
    {path: 'render2', component: RenderComponent2},
    {path: 'pipe', component: Pipe},
    {path: 'listService', component: ListService},
    {path: 'post/:id/:title', component: RouterParameter},
    {path: 'posts', component :Post},
    {path: 'signals', component: Signals},
    {path: 'curd', component: Crud},
    { path: 'addemployee', component: Add },
    { path: 'empList', component: Emplist},
    { path: 'editemployee/:id', component: Add}
];
