import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class UserService {
    private http = inject(HttpClient);

  users: Array<any> = [
    { name: 'John Doe', age: 30, email: 'john@gmail.com' },
    { name: 'John Smith', age: 20, email: 'Smith@gmail.com' },
    { name: 'Lisa Ann', age: 50, email: 'lisa@gmail.com' },
    { name: 'Sam Smith', age: 60, email: 'Sam@gmail.com' },
  ]
  
  getUsers(){
    return this.http.get('https://jsonplaceholder.typicode.com/users');
  }
}
