import { Component, signal, WritableSignal } from '@angular/core';
import { EmployeeModel } from '../../model/employeemodel';
import { email, form, FormField, minLength, required } from '@angular/forms/signals';
import { Api } from '../../service/api';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-add',
  imports: [FormField],
  templateUrl: './add.html',
  styleUrl: './add.scss',
})
export class Add {

  title = signal('Add Employee');
  editmode = signal(false);
  empId = signal('');

  ngOnInit(){
this.empId.set(this.act.snapshot.params['id'] || '');
if(this.empId()){
  this.editmode.set(true);
  this.title.set('Edit Employee');
  this.setEditEmployee(this.empId());
}
}


  constructor(private api: Api, private router: Router, private act: ActivatedRoute) { }

  empModel = signal<EmployeeModel>({
    firstname: '',
    lastname: '',
    email: '',
    phoneno: '',
    address: '',
    iscontract: false
  })

  empForm = form(this.empModel, (schemaPath)=>{
    required(schemaPath.firstname,{message: 'First Name is required'});
    minLength(schemaPath.firstname,5,{message: 'First Name should be minimum 5 charaters'});
    required(schemaPath.email,{message: 'Email is required'});
    email(schemaPath.email,{message: 'Email is not valid'});
    required(schemaPath.phoneno,{message: 'Phone number is required'});
    required(schemaPath.address,{message: 'Address is required'});
  });

  SaveEmployee(event: any){
     event.preventDefault();
if(this.empForm().valid()){
     if(this.editmode()){
      this.api.updateEmployee(this.empId(), this.empForm().value()).subscribe (
        item => {
          alert('Employee Updated Successfully');
          this.router.navigate(['/empList'])
        }
      )
    } else{
        this.api.SaveEmployee(this.empForm().value()).subscribe (
        item => {
          alert('Employee Saved Successfully');
          this.router.navigate(['/empList'])
        }
      )
    }
     }
    console.log(this.empForm().value());
  }

  setEditEmployee(id: string){
    this.api.getEmployeeById(id).subscribe(item => {
      this.empModel.set(item);

      //this.empForm().setValue(item);
    });
  }
}

