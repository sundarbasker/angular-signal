import { Component, signal } from '@angular/core';
import { EmployeeListModel, EmployeeModel } from '../../model/employeemodel';
import { Api } from '../../service/api';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emplist',
  imports: [],
  templateUrl: './emplist.html',
  styleUrl: './emplist.scss',
})
export class Emplist {

  constructor(private api:Api, private router: Router){}

  emplist = signal<EmployeeListModel[]>([]);

  ngOnInit(){
    this.api.GetallEmployees().subscribe(items => {
      this.emplist.set(items);
    })
  }

  deleteEmployee(id: string){
if(confirm('Are you sure to delete this employee?')){
  this.api.deleteEmployee(id).subscribe(() => {
    //Refresh the list after deletion

    this.api.GetallEmployees().subscribe(items =>{
      this.emplist.set(items);
    });
  });
}
  }

  editEmployee(id: string){
  this.router.navigate(['/editemployee', id]);
  }

  navigateToAdd(){
    this.router.navigate(['/addemployee']);
  }
}
