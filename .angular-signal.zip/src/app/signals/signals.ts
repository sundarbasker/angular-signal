import { Component, computed, effect, signal } from '@angular/core';
import { Counter } from '../counter';
import { JsonPipe } from '@angular/common';
import { sign } from 'node:crypto';

@Component({
  selector: 'app-signals',
  imports: [JsonPipe],
  templateUrl: './signals.html',
  styleUrl: './signals.scss',
})
export class Signals {

  userSignal = signal({
    name: 'John',
    email: 'john@gmail.com',
    address: '123 street'
  });

updateUser(){
  this.userSignal.update((currentValue) => {
    return {
      ...currentValue,
      name: 'Jane'
    }
      console.log(currentValue.name);
  });
  console.log(this.userSignal.name);
}

updateUserSet(){
this.userSignal.set({...this.userSignal(), name: 'Sam'});
console.log(this.userSignal.name, 'Set method');
}

  constructor( public counterService: Counter){
    // effect(() =>{
    //   this.total();
    //   window.alert(`The total value changed to ${this.total()}`);
    // });
  }

  counter:number = 0;
  signalCounter = signal(0);

  addCounter(){
    this.counter++;
    this.signalCounter.update((currentValue) =>{
      return currentValue + 1;
    })
  }

  fruitsSignal = signal (['Apple', 'Banana', 'Orange']);

  addFruits(){
    this.fruitsSignal.update((fruitsArray) => {
      return [...fruitsArray, 'Mango'];
    });
  }

  removeFruits(){
    this.fruitsSignal.update((fruitsArray) =>{
      return fruitsArray.slice(0,-1);
    });
  }

  setFruits(){
    this.fruitsSignal.set(['Strawberry', 'Blueberry', 'Rasberry']);
  }

  //Computed Value

  firstNumber = signal(10);
  secondNumber = signal(20);

  total = computed(() => {
    return this.firstNumber() + this.secondNumber();
  });

  changeValue(){
    this.firstNumber.set(50);
    console.log(typeof this.firstNumber);
    console.log(typeof this.secondNumber);
    console.log(this.total);
  }
}
