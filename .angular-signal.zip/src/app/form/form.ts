import { Component, OnInit } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { CommonModule } from '@angular/common'; // Import CommonModule for @if

@Component({
  selector: 'app-form',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './form.html',
  styleUrl: './form.scss',
})
export class Form implements OnInit {
i: any;
remove(arg0: any) {
throw new Error('Method not implemented.');
}

  userForm!: FormGroup;
  formSubmitted = false;

  userForms =  new FormGroup({
     fName : new FormControl('', [Validators.required, Validators.minLength(3)]),
     email : new FormControl('', [Validators.required, Validators.email]),
     address: new FormGroup({
        street :  new FormControl('', [Validators.required, Validators.minLength(3)]),
        city :  new FormControl('', [Validators.required, Validators.minLength(3)]),
        zipcode :  new FormControl('', [Validators.required, Validators.minLength(3)]),
        country :  new FormControl('', [Validators.required, Validators.minLength(3)]),
     }),

     hobbies: new FormArray([]),

     skills: new FormArray([])
     
  });
 
hobbiesArray: FormArray = this.userForms.get('hobbies') as FormArray;
  constructor(private fb: FormBuilder) {
   // console.log(this.fName);
  }

  ngOnInit(): void {
    this.userForm = this.fb.group({
      firstName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      items: this.fb.array([])
    });
  }

  // Helper method to easily access form controls
  get f() {
    return this.userForm.controls;
  }

  get itemsFormArray(){
    return this.userForm.get('items') as FormArray
  }

  addItem(){
    const newItem = this.fb.group({
      firstName: ['', Validators.required],
      email: ['', Validators.required]
    });
    this.itemsFormArray.push(newItem);
  }
  removeItem(index: number) {
    this.itemsFormArray.removeAt(index);
  }
  onSubmit(): void {
    this.formSubmitted = true;

    if (this.userForm.invalid) {
      return;
    }

    console.log('Form Submitted Successfully', this.userForm.value);
    // Further submission logic here
  }


  // Reactive form 

  onSubmitR(){
    console.log(this.userForms);    
  }
  
  addHobby(hobby: string){
    this.hobbiesArray.push(new FormControl(hobby));
    console.log(this.hobbiesArray.value);
  }

  removeHobby(index: number){
    this.hobbiesArray.removeAt(index);
  }

  get Skills(){
    return this.userForms.get('skills') as FormArray;
  }

  addSkills(skills: HTMLInputElement){
    this.Skills.push(
      new FormControl(skills.value)
    )
    skills.value = '';

    console.log(this.userForm.value);

  }

  removeSkills(index: number){
    this.Skills.removeAt(index);

  }
}
