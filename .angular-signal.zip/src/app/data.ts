import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Post {
isEdit: any;
  address: any;
  id: number;
  name: string;
  username: string;
  email: string;
}

@Injectable({
  providedIn: 'root',
})
export class Data {
 // Use inject function for a cleaner constructor in standalone services
  private http = inject(HttpClient); 
  private apiUrl = 'https://jsonplaceholder.typicode.com/users';

  getPosts(): Observable<Post[]> {
    return this.http.get<Post[]>(this.apiUrl);
  }
}
