import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export interface Movie {
  id: number;
  title: string;
  year: number;
  director: string;
}


export interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
}





@Injectable({
  providedIn: 'root',
})
export class Movies {
  private http = inject(HttpClient);
  private apiUrl = 'http://localhost:3000'
 // private apiUrl = 'https://jsonplaceholder.typicode.com';


  constructor(){}

  getUsers(){
    return this.http.get<User[]>('https://jsonplaceholder.typicode.com/users');
  }

  getMovies(){
  return this.http.get<any[]>(`${this.apiUrl}/movies`);
  }

  addMovie(movie: any){
  return this.http.post(`${this.apiUrl}/movies`, movie);
  }
}
