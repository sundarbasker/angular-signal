export interface User {
  id: number;
  name: string;
  email: string;
  city: string;
  isEdit: boolean; // Add an edit state flag
}