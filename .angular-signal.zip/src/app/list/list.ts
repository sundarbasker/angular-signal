import { Component, Inject, OnInit, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common'; // Import CommonModule
import { FormBuilder, FormControl, FormControlName, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Data, Post } from '../data';
import { AsyncPipe, NgForOf } from '@angular/common';
import { map, Observable } from 'rxjs';
import { User } from './user';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import id from '@angular/common/locales/id';

@Component({
  selector: 'app-list',
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  standalone: true,
  templateUrl: './list.html',
  styleUrl: './list.scss',
  providers: [Data]
})

export class List implements OnInit {

  private serviceUrl = 'https://jsonplaceholder.typicode.com/users';

  // Inject the service using inject() function
  private dataService = inject(Data);
  private http = inject(HttpClient);
  saveIcon: boolean = false;
  closeIcon: boolean = false;
  editIcon: boolean = true;
  delIcon: boolean = true;
  isEdit: boolean = false;

  posts: Post[] = [];
  isLoading = true;
  error: string | null = null;


 //tableData!: FormGroup;
   private fb = inject(FormBuilder);
  
  tableData = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      address: this.fb.group({
      city: ['', Validators.required]
      })
    });




  ngOnInit(): void {
    this.fetchData();
  }

  fetchData(): void {
    // this.dataService.getPosts().pipe(
    //   map(data => data.splice(1,4))    
    // ).subscribe(result => result);

    this.dataService.getPosts().subscribe({
      next: (data) => {
        this.posts = data;

        // this.posts = data.filter(data => data.id <= 5)

        this.isLoading = false;
        console.log(this.posts, 'Data value');


      },
      error: (err) => {
        console.error(err);
        this.error = 'Failed to load data.';
        this.isLoading = false;
      }


    });
  }



  editData(post: any) {
    post.isEdit = true;
    this.saveIcon = true;
    this.editIcon = false;
    this.delIcon = false;
    this.closeIcon = true;

    this.tableData.patchValue(post);
  }
  closeEdit(post: any) {
    post.isEdit = false;
    this.saveIcon = false;
    this.editIcon = true;
    this.delIcon = true;
    this.closeIcon = false;
  }
  onSave(post: any, id: number): Observable<User> {
    console.log(post);
    post.isEdit = false;

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      // 'X-API-KEY': environment.apiKey 
    });

    return this.http.patch<User>('this.serviceUrl/${id}', post, { headers });

  }
onPost() {
  if (this.tableData.valid) {
    const updatedData = this.tableData.value;
    this.http.post('https://jsonplaceholder.typicode.com/users', updatedData)
      .subscribe({
        next: (response) => console.log('Update successful', response),
        error: (err) => console.error('Update failed', err)
      });
      this.fetchData();
  }
  
}
  deleteItem(id: number): Observable<any> {
    return this.http.delete(`${this.serviceUrl}/${id}`);
  }

  onDelete(id: number) {
    if (confirm('Are you sure. You want to delete this record?')) { // Optional confirmation
      this.deleteItem(id).subscribe({
        next: () => {
          // Update the UI by filtering out the deleted item
          this.posts = this.posts.filter(item => item.id !== id);
          console.log('Deleted successfully');
           console.log(this.posts, 'Data value');
        },
        error: (err) => console.error('Delete failed', err)
      });
    }
  }

  // Signal to hold the current active filter
  allData1 = this.dataService.getPosts
  allData = signal<any[]>([]); 
  filterCriteria = signal<string>('');
  

  // Computed signal automatically updates when filterCriteria changes
  filteredData = computed(() => {
    const criteria = this.filterCriteria();
    return criteria 
      ? this.allData().filter(item => item.name === criteria) 
      : this.allData();
  });
  
search(value: any){
  alert('test');
   this.filterCriteria.set(value);
}

}
