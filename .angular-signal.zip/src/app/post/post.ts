import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from "@angular/router";

@Component({
  selector: 'app-post',
  imports: [RouterLink],
  templateUrl: './post.html',
  styleUrl: './post.scss',
})
export class Post implements OnInit {

  
  posts = [
    {
      id: 1,
      title: "Title 1",
      content: 'Test content'
    },
        {
      id: 2,
      title: "Title 2",
      content: 'Test content 2'
    },
        {
      id: 3,
      title: "Title 3",
      content: 'Test content 3'
    },
        {
      id: 4,
      title: "Title 4",
      content: 'Test content 4'
    },
        {
      id: 5,
      title: "Title 5",
      content: 'Test content 4'
    }
  ]

  constructor( private route: ActivatedRoute){}

  ngOnInit(): void {

    this.route.queryParamMap.subscribe(value =>{

      const page = value.get('page');
      const order = value.get('orderBy');

      console.log(page);
      console.log(order);
    })

  }

}
